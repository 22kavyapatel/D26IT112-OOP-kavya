
package service;

import model.Account;
import repository.Repository;
import util.Validator;
import exception.AccountNotFoundException;
import exception.BankException;
import exception.InsufficientFundsException;
import exception.InvalidAmountException;

import java.util.ArrayList;

public class BankService {

    private Repository<Account> repository;

    public BankService(Repository<Account> repository) {
        this.repository = repository;
    }

    public void openAccount(Account account) {
        repository.save(account);
        System.out.println("Account opened successfully.");
    }

    public Account findAccount(int accountId)
            throws AccountNotFoundException {

        if (!Validator.isValidAccountId(accountId)) {
            throw new IllegalArgumentException("Invalid account ID.");
        }

        Account account = repository.findById(String.valueOf(accountId));

        if (account == null) {
            throw new AccountNotFoundException(
                    "Account not found: " + accountId);
        }

        return account;
    }

    public void deposit(int accountId, long amount)
            throws AccountNotFoundException, InvalidAmountException {

        Account account = findAccount(accountId);
        account.deposit(amount);

        System.out.println("Deposit successful.");
    }

    public void withdraw(int accountId, long amount)
            throws AccountNotFoundException,
                   InvalidAmountException,
                   InsufficientFundsException {

        Account account = findAccount(accountId);
        account.withdraw(amount);

        System.out.println("Withdrawal successful.");
    }

    public void transfer(int fromId, int toId, long amount)
            throws BankException {

        Account source = findAccount(fromId);
        Account destination = findAccount(toId);

        SafeTransfer.transfer(source, destination, amount);

        System.out.println("Transfer successful.");
    }

    public void printStatement(int accountId)
            throws AccountNotFoundException {

        Account account = findAccount(accountId);

        System.out.println("----- ACCOUNT STATEMENT -----");
        System.out.println("Account ID: " + accountId);
        System.out.println("Account Type: "
                + account.getClass().getSimpleName());
        System.out.println("Balance: " + account.getBalance());
        System.out.println("-----------------------------");
    }

    public void listAccounts() {
        ArrayList<Account> accounts = repository.findAll();

        if (accounts.isEmpty()) {
            System.out.println("No accounts available.");
            return;
        }

        for (Account account : accounts) {
            System.out.println(account);
        }
    }
}
